<template>
    <div style="overflow: hidden">
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="1">
            <template #hotspots>
                <iv-pane position="left" format="full">
                    <iv-sidebar-content :showPagination="true">
                        <iv-sidebar-section title="Grinding and Polishing" icon="book-open">
                            A fine mechanical polish is required for specimens that will be analyzed using optical microscopy. Mechanical grinding and polishing consists of removing material from a specimen with increasingly fine grit grinding paper or polishing compounds. <br><br>

                            Common practice:
                            <ul>
                                <li> Hold a specimen at one orientation per grinding/polishing step to keep scratches in a uniform direction. </li>
                                <li> Rotate the sample 90˚ between steps so that it is apparent when all scratches from the previous step are removed. </li>
                                <li> Clean, uncontaminated grinding paper and polishing pads are crucial to good specimen preparation. </li>
                                <li> Over-polishing can also damage a specimen, particularly for soft materials, or if there is a large hardness difference between phases present in a material. </li>
                            </ul>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Video" icon="video" theme="Lime">
                            Watch this video of the procedure being performed! <br><br>
                            <div style="text-align: center;">
                                <iv-button style="padding-bottom: 35px;" @click="showModal = true">Watch video</iv-button>
                            </div><br>
                            For more of the video, check <a href="https://www.youtube.com/watch?v=UuHofNW40Yw" target="_blank">here</a>.
                            <!-- https://video.wixstatic.com/video/bc314c_c64ca42c9c854268af2dbeee3ab205e1/720p/mp4/file.mp4 -->
                            <!-- https://www.youtube.com/watch?v=UuHofNW40Yw -->
                            <VideoModal 
                                video="https://video.wixstatic.com/video/bc314c_c64ca42c9c854268af2dbeee3ab205e1/720p/mp4/file.mp4" 
                                v-if="showModal" @close="showModal = false">
                            </VideoModal>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Game" icon="gamepad" theme="Purple">
                            Try out the game on the right to test your understanding!
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>
            </template>

            <!-- Game -->
            <div class="game">
                <iframe class="_3S5H9" title="htmlComp-iframe" name="htmlComp-iframe" width="950vh" height="535vw" data-src="" src="https://polishing.netlify.app" />
            </div>
        </iv-visualisation>
    </div>
</template>

<script>
import vue_config from '../../vue.config.js'
import VideoModal from '../components/VideoModal.vue'

export default {
    name:"polishing",
    components: {
        VideoModal,
    },
    data(){
        return {
            pageName:"Polishing",
            vue_config,
            showModal: false,
        };
    },
}
</script>

<style>
.game {
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
</style>