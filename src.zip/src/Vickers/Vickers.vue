<template>
    <div style="overflow: hidden">
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="3">
            <template #hotspots>
                <iv-pane position="left" format="full">
                    <iv-sidebar-content :showPagination="true">
                        <iv-sidebar-section title="Vickers Hardness Test" icon="book-open">
                            The Vickers hardness test is used to determine hardness in materials in the micro hardness test load range. <br><br>

                            A method consists of indenting the test material with a diamond indenter of a load of 1 to 100 kilograms-force (kgf) for 10 to 15 seconds. The hardness value is obtained from the force applied and area of indentation. <br><br>

                            <div class="center">
                                <!-- https://static.wixstatic.com/media/bc314c_26372bd27c87491ea212777874680e55~mv2.png/v1/crop/x_0,y_0,w_208,h_159/fill/w_208,h_159,al_c,q_85/equation.webp -->
                                <img src="https://static.wixstatic.com/media/bc314c_26372bd27c87491ea212777874680e55~mv2.png/v1/crop/x_0,y_0,w_208,h_159/fill/w_208,h_159,al_c,q_85/equation.webp" 
                                alt="Image of microstructure of ASTM A36 steel showing ferrite (white) and pearlite (black)"
                                style="">
                            </div>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Fundamental Equation" icon="calculator" theme="Gold">
                            Hv = constant &times; <sup>test force</sup>&frasl;<sub>surface of indentation</sub> <br><br>
                            <div class="center">
                                <iv-equation-box equation="Hv = 1.020 \times \sin(\frac{136}{2}) \times \frac{2F}{D^2}" />
                            </div>
                            Where: <br>
                            D = <sup>(d1 + d2)</sup>&frasl;<sub>2</sub> = mean diagonal length of indentation (mm) <br>
                            F = applied load (N)
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Video" icon="video" theme="Lime">
                            Watch this video of the procedure being performed! <br><br>
                            <div style="text-align: center;">
                                <iv-button style="padding-bottom: 35px;" @click="showModal = true">Watch video</iv-button>
                            </div>
                            <!-- https://video.wixstatic.com/video/bc314c_69d5bf7353d74de69c78e075b0033892/1080p/mp4/file.mp4 -->
                            <!-- No reference -->
                            <VideoModal 
                                video="https://video.wixstatic.com/video/bc314c_69d5bf7353d74de69c78e075b0033892/1080p/mp4/file.mp4" 
                                reference="" 
                                v-if="showModal" @close="showModal = false">
                            </VideoModal>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Game" icon="gamepad" theme="Purple">
                            Try out the game on the right to test your understanding!
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>
            </template>

            <!-- Game -->
            <div class="game">
                <iframe class="_3S5H9" title="htmlComp-iframe" name="htmlComp-iframe" width="950vh" height="535vw" data-src="" src="https://vickershardnesstest.netlify.app/" />
            </div>
        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js'
import VideoModal from '../components/VideoModal.vue'

export default {
    name:"vickers",
    components: {
        VideoModal,
    },
    data(){
        return {
            pageName:"Vickers Hardness Test",
            vue_config,
            showModal: false,
        };
    },
}
</script>
<style>
.game {
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
.center {
    display:flex;
    flex-direction: column;
    align-items: center;
    /* margin-top: 50px; */
}
</style>