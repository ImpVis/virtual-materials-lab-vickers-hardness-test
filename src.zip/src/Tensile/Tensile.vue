<template>
    <div style="overflow: hidden;">
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="5">
            <template #hotspots>
                <iv-pane position="left" format="full">
                    <iv-sidebar-content :showPagination="true">
                        <iv-sidebar-section title="Tensile Test" icon="book-open">
                            Tensile testing is a destructive form of testing where a controlled (constant) tension is applied to pull the sample until it is fully fails. It is used to find the strength, i.e. how strong the material is and how much it can stretch before breakage. <br><br>

                            This is a method to determine the following properties of the material (open the <i>Properties</i> hotspot for more info):
                            <ul>
                                <li>Yield strength</li>
                                <li>Ultimate tensile strength</li>
                                <li>Ductility</li>
                                <li>Strain hardening characteristics</li>
                                <li>Young's modulus</li>
                                <li>Poisson's ratio</li>
                            </ul>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Step 1" icon="ruler" theme="Lime">
                            The sample is measured in all dimensions prior to the extension process. Black lines are marked as shown on the sample as the reference for post-extension measurement. <br><br>
                            
                            Check out the video below then try out the game on the right. Open the <i>Samples</i> hotspot for more information on each sample. <br><br>
                            <div style="text-align: center;">
                                <iv-button style="padding-bottom: 35px;" @click="showModal0 = true">Watch video</iv-button>
                            </div>
                            <VideoModal 
                                video="https://video.wixstatic.com/video/bc314c_1918e310417d4579a5494c8be72ba0ad/1080p/mp4/file.mp4"
                                reference="" 
                                v-if="showModal0" @close="showModal0 = false">
                            </VideoModal>    
                              
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Step 2" icon="wrench" theme="Lime">
                            Attach the sample onto the Tensile testing machine. Align the holes with the slots and clamp the test piece in the upper clamp, then clamp the lower end of the test piece. <br><br>
                            
                            Check out the video below then click on the <i>Step 2</i> tab at the top to try the game! <br>
                            <div style="text-align: center;">
                                <iv-button style="padding-bottom: 35px;" @click="showModal1 = true">Watch video</iv-button>
                            </div>
                            <VideoModal 
                                video="https://video.wixstatic.com/video/bc314c_78b34cbd1d8942298c577a04b092ba53/1080p/mp4/file.mp4"
                                reference="" 
                                v-if="showModal1" @close="showModal1 = false">
                            </VideoModal>      
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Step 3" icon="cogs" theme="Lime">
                            Run the test! (Click on the <i>Step 3</i> tab at the top) <br><br> 

                            Click on a sample to watch the test being performed on it. <br><br>

                            <div style="text-align: center;">
                                <iv-button style="padding-bottom: 35px;" onclick="location.href='https://9f8d9c45-e3fa-46c2-9d14-848d68af3b0d.filesusr.com/ugd/bc314c_bea97ea3bfe54f3ebc973e1110818a52.csv?dn=MaterialsLabData-1a.csv';">Export raw data</iv-button>
                            </div>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Comparison" icon="poll" theme="Purple">
                            Click on the <i>Comparison</i> tab to check each sample out. Open the <i>Results</i> hotspot to see the load-extension curves.
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>

                
                <!-- Hotspot for toggle  -->
                <iv-fixed-hotspot position="top" style="z-index: 1;" transparent>
                    <div class="center">
                        <iv-toggle-advance :modes=modeNames @toggleswitched="changeToggle" />
                    </div>
                </iv-fixed-hotspot>
                

                <!-- Hotspots for pictures -->
                <iv-toggle-hotspot position="bottom" title="Properties" style="z-index: 20;"> 
                    <img src="https://static.wixstatic.com/media/bc314c_74c650663ad3454394cafb7b64aecb36~mv2.jpg/v1/fill/w_725,h_538,al_c,q_85,usm_0.66_1.00_0.01/Uniaxial.webp" 
                        alt="Key properties of a material"
                        style="">
                </iv-toggle-hotspot>

                <iv-toggle-hotspot position="bottom" title="Samples" style="z-index: 20;"> 
                    <img src="https://static.wixstatic.com/media/bc314c_591ca2b4b93c47f8ba323c959dbf2aa5~mv2.png/v1/fill/w_836,h_556,al_c,q_90,usm_0.66_1.00_0.01/Screenshot%202021-02-15%20at%2023_54_35.webp" 
                        alt="Information about each sample"
                        style="">
                </iv-toggle-hotspot>

                <iv-toggle-hotspot position="bottom" title="Results" style="z-index: 20;"> 
                    <img src="https://static.wixstatic.com/media/bc314c_005fe4d729644f60819b6c26a3cad2d0~mv2.png/v1/fill/w_850,h_241,al_c,q_85,usm_0.66_1.00_0.01/graph.webp" 
                        alt="Load extension curves for each sample"
                        style="">
                </iv-toggle-hotspot>
            </template>

            <!-- Games -->
            <div class="game" style="padding-top: 5vh;">
                <iframe v-if="toggle==0" class="_3S5H9" title="htmlComp-iframe" name="htmlComp-iframe" width="950vh" height="535vw" data-src="" src="https://tensilemeasure.netlify.app/" />

                <iframe v-if="toggle==1" class="_3S5H9" title="htmlComp-iframe" name="htmlComp-iframe" width="950vh" height="535vw" data-src="" src="https://tensileattach.netlify.app/" />
                
                <div v-if="toggle==2">
                    <div class="sample-images">
                        <img src="https://static.wixstatic.com/media/bc314c_9f25da03c41f41aaa9ea0dac155c5d66~mv2.png/v1/fill/w_80,h_289,al_c,q_85,usm_0.66_1.00_0.01/Sample%201.webp" 
                            alt="Sample 1"
                            class="image-button"
                            id="image1"
                            @mousedown="showSample1 = true"
                            @mouseover="showText = 1"
                            @mouseleave="showText = 0">

                        <img src="https://static.wixstatic.com/media/bc314c_94a5403483f44c148fba9660ae8d2aae~mv2.png/v1/fill/w_80,h_289,al_c,q_85,usm_0.66_1.00_0.01/Sample%202.webp" 
                            alt="Sample 2"
                            class="image-button"
                            id="image2"
                            @mousedown="showSample2 = true"
                            @mouseover="showText = 2"
                            @mouseleave="showText = 0">

                        <img src="https://static.wixstatic.com/media/bc314c_35bbf70038394044a237f6de5b72ea16~mv2.png/v1/fill/w_80,h_289,al_c,q_85,usm_0.66_1.00_0.01/Sample%203.webp" 
                            alt="Sample 3"
                            class="image-button"
                            id="image3"
                            @mousedown="showSample3 = true"
                            @mouseover="showText = 3"
                            @mouseleave="showText = 0">

                        <img src="https://static.wixstatic.com/media/bc314c_f911e838795248459667cfa25b9602eb~mv2.png/v1/fill/w_80,h_289,al_c,q_85,usm_0.66_1.00_0.01/Sample%204.webp" 
                            alt="Sample 4"
                            class="image-button"
                            id="image4"
                            @mousedown="showSample4 = true"
                            @mouseover="showText = 4"
                            @mouseleave="showText = 0">

                        <img src="https://static.wixstatic.com/media/bc314c_7ed6d889928f474daec935839d9778e8~mv2.png/v1/fill/w_80,h_289,al_c,q_85,usm_0.66_1.00_0.01/Sample%205.webp" 
                            alt="Sample 5"
                            class="image-button"
                            id="image5"
                            @mousedown="showSample5 = true"
                            @mouseover="showText = 5"
                            @mouseleave="showText = 0">

                        <VideoModal 
                            video="https://video.wixstatic.com/video/bc314c_f4582f4b88a84e7b9d323906f858c337/1080p/mp4/file.mp4"
                            reference="" 
                            v-if="showSample1" @close="showSample1 = false">
                        </VideoModal>   

                        <VideoModal 
                            video="https://video.wixstatic.com/video/bc314c_34d03f0e7e7c47b68bb970c1800f913d/1080p/mp4/file.mp4"
                            reference="" 
                            v-if="showSample2" @close="showSample2 = false">
                        </VideoModal>   

                        <VideoModal 
                            video="https://video.wixstatic.com/video/bc314c_7886d18d026f490cae7796e6959d1402/1080p/mp4/file.mp4"
                            reference="" 
                            v-if="showSample3" @close="showSample3 = false">
                        </VideoModal>   

                        <VideoModal 
                            video="https://video.wixstatic.com/video/bc314c_f9be4a058cd24920a0f7aa1fb79ff0fd/1080p/mp4/file.mp4"
                            reference="" 
                            v-if="showSample4" @close="showSample4 = false">
                        </VideoModal>   

                        <VideoModal 
                            video="https://video.wixstatic.com/video/bc314c_123c9e062c1a42e19b2c2c9afe517944/1080p/mp4/file.mp4"
                            reference="" 
                            v-if="showSample5" @close="showSample5 = false">
                        </VideoModal>   

                        
                        
                    </div>
                    <div class="game">
                        <p v-if="showText == 1">Sample 1: Pure Aluminium - fine grained, annealed</p>
                        <p v-if="showText == 2">Sample 2: Pure Aluminium - fine grained, cold worked</p>
                        <p v-if="showText == 3">Sample 3: Aluminiun/Magnesium - annealed</p>
                        <p v-if="showText == 4">Sample 4: Aluminium - 4% Cu alloy (Duralumin)</p>
                        <p v-if="showText == 5">Sample 5: Aluminium - 4% Cu alloy (incorrect heat treatment)</p>
                    </div>
                </div>
                

                <iframe v-if="toggle==3" class="_3S5H9" title="htmlComp-iframe" name="htmlComp-iframe" width="950vh" height="535vw" data-src="" src="https://tensilecompare.netlify.app/" />
            </div>
        </iv-visualisation>
    </div>
</template>

<script>
import vue_config from '../../vue.config.js'
import VideoModal from '../components/VideoModal.vue'

export default {
    name:"tensile",
    components: {
        VideoModal,
    },
    data() {
        return {
            pageName:"Tensile Test",
            vue_config,
            showModal0: false,
            showModal1: false,
            modeNames: ["Step 1", "Step 2", "Step 3", "Comparisons"],
            toggle: 0,
            showSample1: false,
            showSample2: false,
            showSample3: false,
            showSample4: false,
            showSample5: false,
            showText: 0,
        };
    },
    methods: {
        changeToggle(e) {
            this.toggle = e;
        },
    }
}
</script>

<style>
.game {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
    /* border: 5px solid #555; */
}
.center {
    display:flex;
    flex-direction: column;
    align-items: center;
    /* margin-top: 50px; */
}
.image-button {
    z-index: 10;
    cursor: pointer;
    padding: 2%;
    padding-top: 2vh;
    /* height: 100px; */
    /* border: 5px solid #555; */
}
.sample-images {
    display: grid;
    grid-template-columns: repeat(5, 150px);
    /* gap: 10%; */
    place-items: center;
    place-content: center;
}
</style>