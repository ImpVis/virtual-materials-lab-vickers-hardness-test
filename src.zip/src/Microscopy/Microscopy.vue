<template>
    <div style="overflow: hidden">
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="2">
            <template #hotspots>
                <iv-pane position="left" format="full">
                    <iv-sidebar-content :showPagination="true">
                        <iv-sidebar-section title="Microscopy" icon="book-open">
                            Microscopy is a material microstructure analysis to study the microstructural features of the material under magnification. The properties of a material determine how well it will perform under a given application, and these properties are dependent on the structure of the material. <br><br>

                            The images captured by digital microscopes can identify grain size and structure, phase distribution, microscopic defects and how a component/product has been made (cast/forged/rolled). Sample preparation (i.e. grinding and polishing) is required prior to microscopy analysis.
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Pearlite Percentage Determination" icon="search">
                            Have a look at the <i>Crystal Structure</i> hotspot at the bottom. <br><br>

                            The amount of pearlite in the structure increases with increasing carbon content. The strength of the steel increases with the amount of pearlite and the strength of pearlite can be increased by decreasing the spacing between the alternating sheets of ferrite and cementite.
                        </iv-sidebar-section>

                        <iv-sidebar-section title="The Effect of Grain Size" icon="atom">
                            Check out the <i>Stress-Strain Curves</i> hotspot at the bottom. Smaller grains imply more grain boundaries which make it more difficult for a crack to propagate from one grain into another. As the grain size increases, the alloy’s:
                            <ul>
                                <li>Tensile strength (Rm) and yield strength (Re) decrease</li>
                                <li>Elongation at fracture (A%) increases</li>
                                <li>Ductile-brittle transition temperature increases</li>
                            </ul>

                            The average grain size of an alloy is generally expressed in terms of the grain size number, ASTM. The value of ASTM ranges from 0 to 12 where 0 corresponds to coarse grained, whereas one with a grain size of ASTM 12 would be extremely fine. The grain size may be estimated by comparing with standard grain size charts (see hotspot) and the values can be converted into an average grain diameter using the <i>Table</i> hotspot.
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Fundamental Equations" icon="calculator" theme="Gold">
                            <div class="center">
                                <label for="#hall-petch">Hall Petch Equation</label>
                                <iv-equation-box id="hall-petch" equation="\sigma_{yield} = \sigma_i + \frac{k_y}{\sqrt{d}}" />
                            </div>
                            Where: <br>
                            <!-- This looks off -->
                            &sigma;<sub>yield</sub> = Yield stress <br>
                            &sigma;<sub>i</sub> = Intrinsic lattice strength / resistance to yield <br>
                            &sigma;<sub>f</sub> = Stress required to propagate micro crack <br>
                            k<sub>y</sub> = Constant relating to grain boundary resistance to yielding <br>
                            k<sub>f</sub> = Constant relating to grain boundary resistance to fracture <br>
                            D = Grain diameter <br>
                            
                            <div class="center">
                                <!-- https://static.wixstatic.com/media/bc314c_c334c501288f43d0b70833f20b44012f~mv2.png/v1/fill/w_446,h_340,al_c,q_85,usm_0.66_1.00_0.01/Screenshot%202021-03-15%20at%2014_18_30.webp -->
                                <img src="https://static.wixstatic.com/media/bc314c_c334c501288f43d0b70833f20b44012f~mv2.png/v1/fill/w_446,h_340,al_c,q_85,usm_0.66_1.00_0.01/Screenshot%202021-03-15%20at%2014_18_30.webp" 
                                alt="Image of microstructure of ASTM A36 steel showing ferrite (white) and pearlite (black)"
                                style="width: 100%;">
                            </div>
                            <ul>
                                <li>Grain refinement simultaneously improves both yield stress and cleavage resistance</li>
                                <li>Grain boundary resistance to fracture is much greater than grain boundary resistance to yielding (k<sub>f</sub> >> k<sub>y</sub>)</li>
                                <li>A decrease in ductile-brittle transition temperature (DBTT) with a decrease in grain size</li>
                            </ul>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Game" icon="gamepad" theme="Purple">
                            Try out the game on the right to test your understanding!
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>

                <!-- Hotspots for pictures -->
                <iv-toggle-hotspot position="bottom" title="Crystal Structure">
                    <div style="height: 100%;">
                        <img src="https://static.wixstatic.com/media/bc314c_54ce14daed9344e1a332e98ab8cce596~mv2.png/v1/fill/w_600,h_379,al_c,q_85,usm_0.66_1.00_0.01/Example%20image.webp" 
                            alt="Image of microstructure of ASTM A36 steel showing ferrite (white) and pearlite (black)"
                            style="">
                    </div>
                </iv-toggle-hotspot>

                <iv-toggle-hotspot position="bottom" title="Stress-Strain Curves">
                    <div style="height: 100%;">
                        <img src="https://static.wixstatic.com/media/bc314c_643fc97eef3a415cb6caf59210e5f16d~mv2.jpg/v1/fill/w_407,h_317,al_c,q_80,usm_0.66_1.00_0.01/stress-strain_curve_for_a_typical_steel_.webp" 
                            alt="Stress-strain curve of steel with varying grain size"
                            style="">
                    </div>
                </iv-toggle-hotspot>

                <iv-toggle-hotspot position="bottom" title="Grain Size Chart">
                    <div style="height: 100%;">
                        <img src="https://static.wixstatic.com/media/bc314c_9ec11d8600b44963881423dfe4a573c4~mv2.gif" 
                            alt="Stress-strain curve of steel with varying grain size"
                            style="">
                    </div>
                </iv-toggle-hotspot>
                
                <iv-toggle-hotspot position="bottom" title="Grain Size Table">
                    <div style="height: 100%;">
                        <img src="https://static.wixstatic.com/media/bc314c_c76197df952b46f6836737c6f3469fa8~mv2.png/v1/fill/w_462,h_374,al_c,q_85,usm_0.66_1.00_0.01/ASTM%20table.webp" 
                            alt="Stress-strain curve of steel with varying grain size"
                            style="">
                    </div>
                </iv-toggle-hotspot>
            </template>

            <!-- Game -->
            <div class="game">
                <iframe class="_3S5H9" title="htmlComp-iframe" name="htmlComp-iframe" width="950vh" height="535vw" data-src="" src="https://microscopy.netlify.app/" />
            </div>
        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js'
export default {
    name:"microscopy",
    data() {
        return {
            pageName:"Microscopy",
            vue_config
        }
    }
}
</script>
<style>
.game {
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
.center {
    display:flex;
    flex-direction: column;
    align-items: center;
    /* margin-top: 50px; */
}
</style>