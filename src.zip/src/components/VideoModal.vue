<template>
    <div class="modal-mask">
        <!-- Video -->
        <div class="modal-video_box">
            <iframe class="modal-video" :src="video" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>           
        </div>

        <!-- Video reference -->
        <!-- <div class="modal-reference">
            <a :href="reference" target="_blank" style="color: white;">Reference</a>
        </div> -->

        <!-- Button -->
        <div class="modal-button">
            <iv-button style="padding-bottom: 35px;" class="modal-button" @click="$emit('close')">
                Close
            </iv-button>
        </div>
        

    </div>
</template>

<script>
export default {
    name: "VideoModal",
    props: {
        video: String,
        reference: String,
    }
}
</script>

<style>
.modal-mask {
  position: fixed;
  z-index: 9998;
  top: 0;
  left: 0;
  width: 99vw;
  height: 95vh;
  background-color: rgba(0, 0, 0, 0.8);
  display: table;
  transition: opacity 0.3s ease;
}

.modal-video_box {
    /* display:flex; */
    /* flex-direction: column; */
    /* align-items: center; */
    margin: auto;
    position: relative;
    padding-top: 22.125%;
    padding-bottom: 22.125%;
    width: 78%;
}

.modal-video {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
}

.modal-reference {
    display:flex;
    flex-direction: column;
    align-items: left;
    color: white;
    background-color: rgba(0, 0, 0, 0.5);
    margin: auto;
    width: 78%;
}

.modal-button {
    display:flex;
    flex-direction: column;
    align-items: center;
}

/*
 * The following styles are auto-applied to elements with
 * transition="modal" when their visibility is toggled
 * by Vue.js.
 *
 * You can easily play with the modal transition by editing
 * these styles.
 */

.modal-enter {
  opacity: 0;
}

.modal-leave-active {
  opacity: 0;
}

.modal-enter .modal-container,
.modal-leave-active .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
</style>