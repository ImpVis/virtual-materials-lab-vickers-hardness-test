<template>
    <div style="overflow: hidden;">
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="4">
            <template #hotspots>
                <iv-pane position="left" format="full">
                    <iv-sidebar-content :showPagination="true">
                        <iv-sidebar-section title="Charpy Impact Test" icon="book-open">
                            The Charpy impact test measures the energy absorbed by a standard notched specimen while breaking under an impact load. It acts as a tool to study temperature-dependent ductile–brittle transition. This test consists of striking a suitable specimen with a hammer on a pendulum arm while the specimen is held securely at each end. The energy absorbed by the specimen is determined precisely by measuring the decrease in motion of the pendulum arm. <br><br>

                            <div class="center">
                                <!-- https://static.wixstatic.com/media/bc314c_f16f130210a54e9fabc5730a83a4eb00~mv2.png/v1/fill/w_289,h_192,al_c,q_85,usm_0.66_1.00_0.01/Notched%20sample.webp -->
                                <img src="https://static.wixstatic.com/media/bc314c_f16f130210a54e9fabc5730a83a4eb00~mv2.png/v1/fill/w_289,h_192,al_c,q_85,usm_0.66_1.00_0.01/Notched%20sample.webp" 
                                alt="Image of the Charpy impact test"
                                style="">
                            </div><br>

                            The important factors that affect the toughness of a material include:
                            <ul>
                                <li>Low temperatures</li>
                                <li>High strain rates (by impact or pressurisation)</li>
                                <li>Stress concentrators such as notches, cracks, and voids</li>
                            </ul>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Ductile-Brittle Transition Temperature" icon="exchange-alt">
                            <strong>Ductile to Brittle Transition Temperature (DBTT)</strong> <br>
                            Indicates the temperature where shift from brittle to ductile behaviour occurs. <br><br>

                            DBTT = Temperature at (Upper Shelf Energy + Lower Shelf Energy) &frasl; 2

                            <img src="https://static.wixstatic.com/media/bc314c_9cecf0144b7f4ee08d1236944a1233a5~mv2.png/v1/fill/w_374,h_348,al_c,q_85,usm_0.66_1.00_0.01/Screenshot%202021-03-15%20at%2015_37_10.webp" 
                                alt="Graph of energy absorbed against temperature showing DBTT"
                                style="width: 100%;">

                            <strong>Fracture Appearance Transition Temperature (FATT)</strong> <br>
                            Temperature at which the fracture surface of the broken test piece is 50% brittle/cleavage/crystalline and 50% ductile. <br><br>

                            <strong>Nil Ductility Temperature (NDT)</strong> <br>
                            This is the temperature at which the fracture surface of the broken test piece is 100% brittle/cleavage/crystalline, i.e. fracture initiates with practically no plastic deformation. <br><br>

                            <strong>Fracture Transition Plastic Temperature (FTP)</strong> <br>
                            The temperature at which the fracture changes from totally plastic to substantially brittle. The temperature above which the fracture is 100% ductile (0% cleavage). 

                            <img src="https://static.wixstatic.com/media/bc314c_cc495608e4134306bacde372789aef91~mv2.png/v1/fill/w_473,h_348,al_c,q_85,usm_0.66_1.00_0.01/Screenshot%202021-03-15%20at%2015_37_30.webp" 
                                alt="Graph showing NDT, FTP, FATT"
                                style="width: 100%;">
                            

                        </iv-sidebar-section>

                        <iv-sidebar-section title="Fracture Surface Appearance" icon="search">
                            Have a look at the <i>Frature Surfaces</i> hotspot for reference. <br><br>
                            <strong>Ductile fracture (Plastic deformation)</strong> <br>
                            Surface appears dull and fibrous. <br><br>
                            <strong>Brittle fracture (cleavage)</strong> <br>
                            Surface appears bright, shiny and granular. <br><br>
                            <strong>% Shear</strong> <br>
                            Defines extent of ductile fracture on the surface. <br><br>
                            <strong>% Crystalline</strong> <br>
                            Defines extent of brittle fracture surface. 
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Game" icon="gamepad" theme="Purple">
                            Try out the Charpy Impact Test game to your right! <br><br> 
                            
                            Once you're done with that, click on Percentage Crystallinity Determination to practice identifying different fracture surfaces.
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>

                
                <!-- Hotspot for toggle -->
                <iv-fixed-hotspot position="top" style="z-index: 1; height: 100px" transparent>
                    <div class="center">
                        <iv-toggle-advance :modes=modeNames @toggleswitched="changeToggle" />
                    </div>
                </iv-fixed-hotspot>
                

                <!-- Hotspots for pictures -->
                <iv-toggle-hotspot position="bottom" title="Fracture Surfaces" style="z-index: 10;"> 
                    <img src="https://static.wixstatic.com/media/bc314c_3786f06e71f64f5f9a5def0f6c640be9~mv2.jpg/v1/fill/w_846,h_422,al_c,q_80,usm_0.66_1.00_0.01/Fracture%20surface%20guidance.webp" 
                        alt="Image of fracture surface appearances at different failure types"
                        style="height: 45vh;">
                </iv-toggle-hotspot>
            </template>

            <!-- Game -->
            <div class="game" style="padding-top: 5vh; z-index: 5;">
                <iframe v-if=!toggle class="_3S5H9" title="htmlComp-iframe" name="htmlComp-iframe" width="950vh" height="535vw" data-src="" src="https://charpyimpacttest.netlify.app/" />
                <iframe v-if=toggle class="_3S5H9" title="htmlComp-iframe" name="htmlComp-iframe" width="950vh" height="535vw" data-src="" src="https://charpycrystal.netlify.app/" />
            </div>

        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js'
export default {
    name:"charpy",
    data(){
        return {
            pageName:"Charpy Impact Test",
            vue_config,
            modeNames: ['Charpy Impact Test', "Percentage Crystallinity Determination"],
            toggle: 0,
        }
    },
    methods: {
        changeToggle(e) {
            this.toggle = e;
            console.log(`toggle: ${this.toggle}`)
        }
    }
}
</script>
<style>
.game {
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
.center {
    display:flex;
    flex-direction: column;
    align-items: center;
    /* margin-top: 50px; */
}
</style>